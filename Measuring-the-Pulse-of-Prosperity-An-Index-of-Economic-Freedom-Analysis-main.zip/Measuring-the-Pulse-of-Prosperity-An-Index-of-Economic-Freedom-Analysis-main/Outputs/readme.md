Results of the project
