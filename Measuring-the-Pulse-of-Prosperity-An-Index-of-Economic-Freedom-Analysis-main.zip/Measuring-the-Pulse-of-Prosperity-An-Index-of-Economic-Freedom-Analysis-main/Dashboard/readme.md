Dashboard of our project
